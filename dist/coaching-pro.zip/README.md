# Coaching Pro Theme for BrandID

A Genesis child theme for Coaches, built by brandiD.

## THEME DEMO
https://demo.coaching-pro.thebrandid.com/

## PURCHASE
https://buildmybrandid.com/wordpress-themes/

## INSTALL
1. Make sure you have the Genesis Framework installed first.
2. Go to your WordPress dashboard. Click Appearance -> Themes and then Add New, then Upload Theme.
3. Click Choose File and Upload the file `coaching-pro.zip`
4. Activate the Coaching Pro theme.

## THEME DOCUMENTATION
For theme documentation, please visit: https://buildmybrandid.com/docs/coaching-pro/

## SUPPORT
For theme support, please visit: https://buildmybrandid.com/support/
