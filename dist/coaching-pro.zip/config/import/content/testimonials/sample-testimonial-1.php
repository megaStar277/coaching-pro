<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Testimonial #1 content.
 *
 * Visit Genesis > Child Theme Setup to trigger import.
 *
 * @package Coaching Pro
 */

return array(
	'socialproofslider_testimonial_author_name'  => '<h3>Julie J.</h3>',
	'socialproofslider_testimonial_author_title' => '<p>Richmond, VA</p>',
	'socialproofslider_testimonial_text'         => '<h4>"... I am now a happier individual ..."</h4><p>All I can say is "<strong>wow!</strong>" I\'ve lost 20 lbs and I feel great. Go for it!</p>',
);
