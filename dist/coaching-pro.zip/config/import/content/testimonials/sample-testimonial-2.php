<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Testimonial #2 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

return array(
	'socialproofslider_testimonial_author_name'  => '<h3>Cameron W.</h3>',
	'socialproofslider_testimonial_author_title' => '<p>San Diego, CA</p>',
	'socialproofslider_testimonial_text'         => '<h4>"... an amazing adventure ..."</h4><p>Wow! Finally found something that works. This has been an amazing adventure and the results are proof positive that if you work the plan - the plan will work for you!</p>',
);
