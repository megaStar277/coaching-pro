<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #4 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi non quam in ligula hendrerit aliquam. Sed nec risus elit. Duis quis varius lectus. Proin auctor justo orci, id malesuada nisi volutpat sed. Pellentesque iaculis, odio et bibendum iaculis, purus mauris posuere mi, a interdum orci justo vitae lectus. Cras tincidunt nulla ac purus feugiat facilisis. Pellentesque ultrices, ipsum et semper pulvinar, tortor velit tincidunt diam, porta sodales dui nisl ut massa. Suspendisse id maximus ipsum. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed eget ex nulla. Proin eget varius augue, ac efficitur purus. Aliquam malesuada tortor sit amet enim sagittis, malesuada imperdiet velit ultrices. Sed dictum, augue vel dictum accumsan, ante mauris varius nunc, sed rhoncus sapien nisl eu magna. In ut auctor nisi. Pellentesque euismod facilisis turpis, vel ullamcorper felis vehicula id. Quisque ac ipsum diam. Cras congue, purus in fringilla bibendum, purus nisi tempor ante, in viverra est tellus et ligula.</p>
<!-- /wp:paragraph -->
CONTENT;
