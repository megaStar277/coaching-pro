<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #2 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu imperdiet felis. Sed at laoreet elit. Nam sit amet magna sapien. Cras mi risus, sollicitudin id viverra vel, rhoncus quis justo. Sed hendrerit finibus leo, et luctus arcu tempus vel. Nunc varius enim ac porttitor rutrum. Aliquam non lobortis turpis. Praesent dignissim mollis sollicitudin. Vivamus imperdiet tincidunt lacus quis auctor. Quisque ultricies erat justo, eu sagittis lectus cursus tincidunt. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Morbi lacinia imperdiet aliquet. Phasellus sagittis porta velit ullamcorper ullamcorper. Aliquam molestie molestie erat, non gravida velit porttitor non. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Aliquam vestibulum, massa non rutrum interdum, ex nunc tincidunt nunc, tincidunt consequat massa augue in massa. Sed tempus tincidunt enim, sed aliquam leo mattis in.</p>
<!-- /wp:paragraph -->
CONTENT;
