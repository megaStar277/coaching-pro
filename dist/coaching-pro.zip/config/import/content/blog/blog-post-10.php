<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #10 content.
 *
 * Visit Genesis > Child Theme Setup to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque commodo nisl eget accumsan bibendum. Nam in turpis augue. Praesent finibus odio at placerat aliquam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tempor, urna a vulputate euismod, nunc odio varius ex, sed ullamcorper ligula felis nec arcu. Nunc dictum, est quis porta dictum, magna arcu rutrum metus, a finibus nulla quam id tortor. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Etiam pretium, est nec scelerisque semper, ipsum quam vehicula massa, ut auctor dui urna quis purus. Praesent tempor luctus est, at faucibus justo efficitur vitae. Donec finibus tellus nec consequat lobortis. Suspendisse tristique, lectus tempor tempus congue, ex ante fringilla mauris, nec ultrices velit dui in lorem. Mauris aliquam pharetra erat et mollis. Aenean vestibulum turpis ut bibendum consectetur.</p>
<!-- /wp:paragraph -->
CONTENT;
