<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #8 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean faucibus sed leo quis dignissim. Etiam sollicitudin, lectus sit amet sagittis congue, mi neque egestas magna, ac semper augue tellus at leo. Aenean in lorem ante. Sed iaculis tellus non quam interdum sagittis. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Morbi eleifend risus in enim semper, ac consectetur metus aliquam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed iaculis dapibus erat malesuada scelerisque. In facilisis nunc massa, euismod pellentesque leo dictum et. Nunc convallis pellentesque rhoncus. Nunc libero lacus, pharetra a auctor id, mattis vitae magna.</p>
<!-- /wp:paragraph -->
CONTENT;
