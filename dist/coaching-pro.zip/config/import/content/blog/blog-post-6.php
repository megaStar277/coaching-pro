<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #6 content.
 *
 * Visit Genesis > Child Theme Setup to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In pharetra mi ac consectetur molestie. Ut tellus libero, luctus at vestibulum vel, pretium ut turpis. Aenean quis tempus lectus. Sed nec gravida dolor, sit amet condimentum magna. Nullam et elementum velit, non elementum dolor. Suspendisse nisi odio, pretium ut erat nec, maximus auctor nibh. Curabitur a libero consequat, aliquam purus quis, egestas nisi. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Curabitur nulla lectus, lacinia in laoreet ac, bibendum vel arcu. Aenean condimentum leo nisl, eget posuere dui ultrices nec. Sed euismod mauris odio, id mattis velit vulputate ut. Pellentesque maximus, dui eu tincidunt ullamcorper, augue lacus interdum ipsum, quis vehicula orci nisl vel diam. Quisque varius quam nibh, eu rutrum erat placerat vitae. Nunc id lacus quis nisl ornare porta non lobortis risus. Nulla ultricies lorem id turpis malesuada, tincidunt tincidunt nulla facilisis. Proin faucibus arcu quis urna vestibulum, vel malesuada lorem efficitur.</p>
<!-- /wp:paragraph -->
CONTENT;
