<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #5 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque a mi pulvinar, accumsan mauris in, interdum sem. Suspendisse in justo ac tortor molestie auctor a eu turpis. Proin eros mi, tempus a risus ac, feugiat condimentum erat. Donec egestas magna quis nisi euismod gravida. Phasellus at varius odio. Nulla sit amet faucibus mauris. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nam semper imperdiet felis ac sodales. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam pulvinar leo eu orci facilisis, id faucibus dui bibendum. Suspendisse potenti. Donec eros metus, semper elementum maximus vitae, lacinia ut nisl. Cras varius lobortis justo, sit amet luctus orci aliquam nec. Donec magna odio, congue dignissim pretium in, varius quis magna.</p>
<!-- /wp:paragraph -->
CONTENT;
