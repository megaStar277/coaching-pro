<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #9 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec in risus sed risus tincidunt efficitur eget ac quam. Proin feugiat augue nec leo consectetur blandit. Suspendisse rutrum magna tortor, et porta libero porttitor sed. Pellentesque nisl libero, sollicitudin non purus a, pulvinar porta est. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam efficitur, orci vel porta lobortis, mauris libero varius velit, sit amet hendrerit nulla magna ac felis. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Ut egestas, quam in blandit varius, augue purus dictum erat, eget tincidunt libero quam eget ipsum. Nulla eget finibus urna. Curabitur ligula nisl, dictum sit amet augue id, cursus volutpat nulla. Nullam feugiat risus in tellus accumsan, ac fringilla elit commodo. Proin ultricies orci et augue egestas viverra. Donec eget felis nec nulla auctor congue ac quis turpis. Praesent nec dui malesuada, congue nibh ultricies, eleifend elit. Duis volutpat interdum consectetur.</p>
<!-- /wp:paragraph -->
CONTENT;
