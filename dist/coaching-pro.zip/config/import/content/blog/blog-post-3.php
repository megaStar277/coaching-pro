<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #3 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque lacinia mi vel turpis sagittis, efficitur tincidunt tellus placerat. Ut in turpis malesuada, consequat ex eu, faucibus nunc. Nullam venenatis ante consectetur, molestie tortor ut, dignissim lorem. In gravida mauris eu metus iaculis luctus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Donec tristique, metus ut vestibulum cursus, mi quam finibus lacus, id fringilla nunc sem at justo. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Proin eleifend urna ligula, at iaculis arcu placerat vel. Nam laoreet in turpis non volutpat. Nullam rutrum porta consectetur. Morbi et turpis mattis, hendrerit nisl ac, hendrerit erat. Ut maximus fringilla urna, eget rutrum velit pharetra id. Donec nec nisi vitae elit pharetra ultricies. Etiam ut velit lorem.</p>
<!-- /wp:paragraph -->
CONTENT;
