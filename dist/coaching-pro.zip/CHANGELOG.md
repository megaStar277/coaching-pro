# Coaching Pro Theme Changelog

## [2.0.1] - Dec 8, 2021
* Add: Adds a JSON file to import our Demo Site sample WP Forms.
* Add: Adds a new file to help configure site settings directly after completing the One-Click Theme Setup process.
* Fix: Updates the Onboarding Demo Homepage content to match the Demo Site more closely.

## [2.0.0] - Dec 1, 2021
* Initial Release.
