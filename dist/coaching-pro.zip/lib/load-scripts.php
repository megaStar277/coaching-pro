<?php
/**
 * Loads scripts and stylesheets for Coaching Pro theme.
 *
 * @since 1.0
 *
 * @package Coaching Pro Theme
 */


// Enqueue Scripts and Styles.

// Load the main stylesheet
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'genesis_meta', 'coaching_pro_enqueue_main_stylesheet', 5 );
function coaching_pro_enqueue_main_stylesheet() {

	// $use_minified_stylesheet = get_theme_mod( 'mincss_header_on' );

	// $suffix = ! $use_minified_stylesheet ? '' : '.min';
	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	wp_enqueue_style( $handle , CHILD_THEME_URI . "/style.css", false, CHILD_THEME_VERSION );

	// if ( is_front_page() ) {
	// 	// Enqueue styles
	// 	wp_enqueue_style( 'front-styles', CHILD_THEME_URI . "/home{$suffix}.css", array( 'coaching-pro' ), CHILD_THEME_VERSION, false );
	//
	// }
}


add_action( 'wp_enqueue_scripts', 'coaching_pro_enqueue_scripts_styles' );
/**
 * Enqueue Scripts and Styles
 *
 * @since 1.0.0
 */
function coaching_pro_enqueue_scripts_styles() {
	$suffix = ( defined( 'COACHING_PRO_DEBUG' ) && COACHING_PRO_DEBUG ) ? '' : '.min';

	$googlefontsURL = '//fonts.googleapis.com/css?family='.get_fonts_list();

	// Google fonts.
	wp_enqueue_style( 'coaching-pro-fonts', $googlefontsURL, array(), CHILD_THEME_VERSION );

	// Dashicons.
	wp_enqueue_style( 'dashicons' );

	// Global scripts.
	wp_enqueue_script( 'global-scripts', CHILD_THEME_URI . "/js/global{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );

	// Homepage scripts.
	// if ( is_front_page() ) {
	// 	// Enqueue script
	// 	wp_enqueue_script( 'homepage-scripts', CHILD_THEME_URI . "/js/home{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	// }

	// Responsive menu.
	wp_enqueue_script( 'coaching-pro-responsive-menu', CHILD_THEME_URI. "/js/responsive-menus{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'coaching-pro-responsive-menu',
		'genesis_responsive_menu',
		coaching_pro_responsive_menu_settings()
	);

}

// Returns a URL-encoded list of Google Fonts to enqueue.
function get_fonts_list() {

	// Get the appearance settings array.
	$appearance = genesis_get_config( 'appearance' );

	// Get the list of fonts from the appearance array.
	$editor_fonts = $appearance['editor-fonts'];

	// Create empty var for all text output.
	$output = '';

	// Create array to hold all escaped font names.
	$esc_fontlist = array();

	// Output a list of all chosen fonts.
	foreach ( $editor_fonts as $font ) {

		$fontfamily_escaped = '';
		$fontfamily_escaped .= str_replace( ' ', '+', $font['font'] );
		$fontfamily_escaped .= ':400,700';

		if ( in_array( $fontfamily_escaped, $esc_fontlist ) == false ) {
			$esc_fontlist[] = $fontfamily_escaped;
		}

	}

	$allfonts_str = implode('|', $esc_fontlist);

	$output .= $allfonts_str;

	return $output;

}


/* ADMIN SCRIPTS */
add_action( 'customize_controls_print_footer_scripts', 'coaching_pro_customizer_scripts' );
/**
 * Load customizer scripts.
 *
 * @since  1.0.0
 */
function coaching_pro_customizer_scripts() {
	global $wp_customize;

	if ( ! isset( $wp_customize ) ) {
		return;
	}
	$suffix = ( defined( 'COACHING_PRO_DEBUG' ) && COACHING_PRO_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'customizer_scripts', CHILD_THEME_URI . "/js/customizer-scripts{$suffix}.js", 'jquery' );
	wp_enqueue_script( 'coaching_pro_customizer_controls_scripts', CHILD_THEME_URI . "/js/customizer-controls{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_enqueue_style( 'customizer_styles', CHILD_THEME_URI . "/css/admin-styles{$suffix}.css", CHILD_THEME_VERSION, false );
}

/**
 * Define our responsive menu settings.
 *
 * @since  1.0.0
 */
function coaching_pro_responsive_menu_settings() {

	$settings = array(
	'mainMenu'          => __( 'Menu', 'coaching-pro' ),
	'menuIconClass'     => 'dashicons-before dashicons-menu',
	'subMenu'           => __( 'Submenu', 'coaching-pro' ),
	'subMenuIconsClass' => 'dashicons-before dashicons-arrow-down-alt2',
	'menuClasses'       => array(
		'combine' => array(
			'.nav-primary',
			'.nav-header',
		),
		'others'  => array(),
	),
	);

	return $settings;

}
