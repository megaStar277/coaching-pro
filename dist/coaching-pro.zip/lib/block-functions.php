<?php
/**
 * Loads Block Editor functions for Coaching Pro theme.
 *
 * @since 1.4.0
 *
 * @package Coaching Pro Theme
 */

// Enable Wide Blocks.
add_theme_support( 'align-wide' );

// Make media embeds responsive.
add_theme_support( 'responsive-embeds' );
